package com.example.leolou;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface regionsAPI {
    @GET("a72cbaeffe816aee2828")
    Call<List<Region>> getRegions();
}
