package com.example.leolou;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity {

    MainViewController controller = new MainViewController();

    TextView mainTextView;
    RecyclerView mainRecyclerView;
    RecyclerView.Adapter mAdapter;
    RecyclerView.LayoutManager layoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainTextView = findViewById(R.id.mainTextView);

        mainRecyclerView = findViewById(R.id.mainRecyclerView);

        mainRecyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(this, mainRecyclerView ,new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View v, int position) {
                        Intent intent = new Intent(v.getContext(),RandoActivity.class);
                        intent.putExtra("id",((MyAdapter)mAdapter).getItem(position).getNom());
                        startActivity(intent);

                    }

                    @Override public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );

        layoutManager = new LinearLayoutManager(this);
        mainRecyclerView.setLayoutManager(layoutManager);



        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://api.npoint.io/").addConverterFactory(GsonConverterFactory.create()).build();
        regionsAPI api = retrofit.create(regionsAPI.class);

        getRegions(api);
    }

    private void getRegions(regionsAPI api) {
        api.getRegions().enqueue(new Callback<List<Region>>() {
            @Override
            public void onResponse(Call<List<Region>> call, Response<List<Region>> response) {
                controller.setRegions(response.body());
                mAdapter = new MyAdapter(controller.getRegions());
                mainRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(Call<List<Region>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();


    }


}
