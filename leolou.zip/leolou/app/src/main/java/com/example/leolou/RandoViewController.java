package com.example.leolou;

import java.util.ArrayList;
import java.util.List;

import androidx.lifecycle.ViewModel;

public class RandoViewController extends ViewModel {
    private List<Rando> randos = new ArrayList<Rando>();

    public List<Rando> getRandos() {
        return randos;
    }

    public void setRandos(List<Rando> l) {randos = l;}

    public RandoViewController() {

    }

}
