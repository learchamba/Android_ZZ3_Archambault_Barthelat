package com.example.leolou;

public class Rando {
    public String nom;

    public String getNom() {
        return nom;
    }

    public Rando(String n) {
        nom = n;
    }
}
