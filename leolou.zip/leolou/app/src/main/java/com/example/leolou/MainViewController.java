package com.example.leolou;


import java.util.ArrayList;
import java.util.List;

import androidx.lifecycle.ViewModel;

public class MainViewController extends ViewModel {

    private List<Region> regions = new ArrayList<Region>();

    public List<Region> getRegions() {
        return regions;
    }

    public void setRegions(List<Region> l) {regions = l;}

    public MainViewController() {
        /*regions.add(new Region("Auvergne", "Clermont-Ferrand"));
        regions.add(new Region("Bretagne", "Nantes"));
        regions.add(new Region("Le NOOOOOOOOOOOORD", "Awoingt"));*/
    }

}