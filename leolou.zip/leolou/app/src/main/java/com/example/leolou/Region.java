package com.example.leolou;

public class Region {

    private String nom;
    private String chefLieu;

    public String getNom() {
        return nom;
    }

    public String getChefLieu() {
        return chefLieu;
    }

    public Region(String n, String cl) {
        nom = n;
        chefLieu = cl;
    }

}
