package com.example.leolou;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private List<Region> mDataset;

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class MyViewHolder extends RecyclerView.ViewHolder {//implements View.OnClickListener{
        // each data item is just a string in this case
        public TextView textViewN;
        public TextView textViewCL;
        public MyViewHolder(View v) {
            super(v);
            textViewN= v.findViewById(R.id.textViewNom);
            textViewCL= v.findViewById(R.id.textViewChefLieu);
        }

//        @Override
//        public void onClick(View v) {
//            v.getContext().startActivity(new Intent(v.getContext(),RandoActivity.class));
//        }
    }

//    public static class MyClickListener implements View.OnClickListener{
//        @Override
//        public void onClick(final View view) {
//            int itemPosition = mainRecyclerView.getChildLayoutPosition(view);
//            String item = mList.get(itemPosition);
//            Toast.makeText(mContext, item, Toast.LENGTH_LONG).show();
//        }
//    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public MyAdapter(List<Region>  myDataset) {
        mDataset = myDataset;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                     int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.mytextview, parent, false);
        //...
        MyViewHolder vh = new MyViewHolder(v);
        //v.setOnClickListener();
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        holder.textViewN.setText(mDataset.get(position).getNom());
        holder.textViewCL.setText(mDataset.get(position).getChefLieu());

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public Region getItem(int position) {
        return mDataset.get(position);
    }
}