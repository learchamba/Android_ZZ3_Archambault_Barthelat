package com.example.leolou;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RandoActivity extends AppCompatActivity {

    RandoViewController controller = new RandoViewController();


    TextView mainTextView;
    RecyclerView randoRecyclerView;
    RecyclerView.Adapter mAdapter;
    RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.randoview);
        mainTextView = findViewById(R.id.mainTextView);

        randoRecyclerView = findViewById(R.id.randoRecyclerView);

        layoutManager = new LinearLayoutManager(this);
        randoRecyclerView.setLayoutManager(layoutManager);



        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://api.npoint.io/").addConverterFactory(GsonConverterFactory.create()).build();
        randosAPI api = retrofit.create(randosAPI.class);

        getRandos(api);
    }

    private void getRandos(randosAPI api) {
        api.getRandos().enqueue(new Callback<List<Rando>>() {
            @Override
            public void onResponse(Call<List<Rando>> call, Response<List<Rando>> response) {
                controller.setRandos(response.body());
                mAdapter = new RandoAdapter(controller.getRandos());
                randoRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(Call<List<Rando>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

}
